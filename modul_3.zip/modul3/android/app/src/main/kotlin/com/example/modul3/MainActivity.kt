package com.example.modul3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
