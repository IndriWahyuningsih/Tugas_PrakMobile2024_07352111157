import 'package:flutter/material.dart';
import '../models/book.dart';
import '../services/api_service.dart';
import 'add_edit_book_screen.dart';

class BookDetailScreen extends StatelessWidget {
  final String bookId;
  final ApiService apiService = ApiService();

  BookDetailScreen({required this.bookId});

  Future<void> _deleteBookAndNavigate(
      BuildContext context, String bookId) async {
    try {
      await apiService.deleteBook(bookId);
      Navigator.pop(context, true);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Buku'),
      ),
      body: FutureBuilder<Book>(
        future: apiService.fetchBookById(bookId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData) {
            return Center(child: Text('Buku tidak ditemukan'));
          } else {
            final book = snapshot.data!;
            return Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(book.title,
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('Penulis: ${book.author}',
                      style: TextStyle(fontSize: 16)),
                  SizedBox(height: 8),
                  Text(book.description),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      ElevatedButton(
                        onPressed: () async {
                          final result = await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  AddEditBookScreen(book: book),
                            ),
                          );
                          if (result == true) {
                            Navigator.pop(context,
                                true);
                          }
                        },
                        child: Text('Edit'),
                      ),
                      SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: () async {
                          await _deleteBookAndNavigate(context, book.id);
                        },
                        child: Text('Hapus'),
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red),
                      ),
                    ],
                  ),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
