import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/book.dart';

class ApiService {
  static const String baseUrl = 'https://events.hmti.unkhair.ac.id/api';

  // Fungsi untuk mengambil daftar buku
  Future<List<Book>> fetchBooks() async {
    final response = await http.get(Uri.parse('$baseUrl/books'));
    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map<Book>((item) => Book.fromJson(item)).toList();
    } else {
      throw Exception('Tidak ada buku tersedia');
    }
  }

  // Fungsi untuk mengambil detail buku berdasarkan id (diubah menjadi String)
  Future<Book> fetchBookById(String id) async {
    final response = await http.get(Uri.parse('$baseUrl/books/$id'));
    if (response.statusCode == 200) {
      return Book.fromJson(json.decode(response.body));
    } else {
      throw Exception('Tidak ada buku tersedia');
    }
  }

  // Fungsi untuk menambahkan buku baru
  Future<void> addBook(Book book) async {
    final response = await http.post(
      Uri.parse('$baseUrl/books'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(book.toJson()),
    );

    if (response.statusCode != 201) {
      throw Exception('Gagal tambah buku');
    }
  }

  // Fungsi untuk memperbarui buku berdasarkan id (diubah menjadi String)
  Future<void> updateBook(String id, Book book) async {
    final response = await http.put(
      Uri.parse('$baseUrl/books/$id'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(book.toJson()),
    );

    if (response.statusCode != 200) {
      throw Exception('Gagal perbarui buku');
    }
  }

  // Fungsi untuk menghapus buku berdasarkan id (diubah menjadi String)
  Future<void> deleteBook(String id) async {
    final response = await http.delete(Uri.parse('$baseUrl/books/$id'));

    if (response.statusCode == 200 || response.statusCode == 204) {
      // Menghapus berhasil, tidak ada konten yang perlu dikembalikan
      return;
    } else {
      throw Exception('Gagal Menghapus buku');
    }
  }
}
